Option 1

Sum of SOZ bar heights + Sum of N_SOZ bar heights == 1 