Option 2

Sum of SOZ bar heights == 1
Sum of N_SOZ bar heights == 1 

then soz + n_soz == 2